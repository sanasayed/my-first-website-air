document.write("This is javascript code ");
var visitorsAge = prompt("What's your age?");
var visitorsName = prompt("What's your name?");
var age= parseInt(visitorsAge);
var rno= Math.floor(Math.random()* age)+1;
document.write(" Hello " + visitorsName + " your current age is "+visitorsAge+" "+rno);

